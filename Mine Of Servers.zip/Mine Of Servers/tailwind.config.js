module.exports = {
  content: [
    "./public/Mine Of Servers.html",
    "./src/**/*.{html,js}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#1d4ed8', // Example primary color
        secondary: '#9333ea', // Example secondary color
      },
      screens: {
        'sm': '640px',
        'md': '768px',
        'lg': '1024px',
        'xl': '1280px',
        '2xl': '1536px',
      },
    },
  },
  plugins: [],
};