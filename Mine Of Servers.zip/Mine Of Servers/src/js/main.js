// Main JavaScript file for the Minecraft community website

// =========================
// Firebase Initialization
// =========================
import { app, auth, db } from "./firebase.js";

// =========================
// Global Variables
// =========================
let currentUser = null;

// =========================
// Authentication State Change
// =========================
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-auth.js";

onAuthStateChanged(auth, user => {
    currentUser = user;
    updateUI();
});

// =========================
// UI Update Function
// =========================
function updateUI() {
    const userInfo = document.getElementById('user-info');
    const loginBtn = document.getElementById('login-google');
    const logoutBtn = document.getElementById('logout');

    if (currentUser) {
        userInfo.textContent = `Hola, ${currentUser.displayName || currentUser.email}`;
        loginBtn.classList.add('hidden');
        logoutBtn.classList.remove('hidden');
    } else {
        userInfo.textContent = '';
        loginBtn.classList.remove('hidden');
        logoutBtn.classList.add('hidden');
    }
}

// =========================
// Event Listeners
// =========================
document.getElementById('logout').addEventListener('click', () => {
    signOut(auth);
});

// Additional functions for handling UI interactions can be added here.