# Mine Of Servers

Bienvenido a **Mine Of Servers**, la comunidad definitiva para encontrar, compartir y votar por los mejores servidores de Minecraft (Java y Bedrock).

## 🚀 Instalación y Uso

1. **Clona el repositorio:**
   ```sh
   git clone <url-del-repo>
   cd mine-of-servers
   ```

2. **Instala dependencias:**
   ```sh
   npm install
   ```

3. **Configura tus variables de entorno:**
   - Copia `.env.example` a `.env` y agrega tus credenciales de Firebase.

4. **Desarrolla localmente:**
   ```sh
   npm run start
   ```

5. **Construye los estilos para producción:**
   ```sh
   npm run build
   ```

6. **Despliega en Firebase Hosting:**
   ```sh
   npm run deploy
   ```

## 🛠️ Funcionalidades

- Autenticación con Google y correo electrónico.
- Listado y filtrado de servidores Minecraft.
- Foro y comentarios en tiempo real (Firestore).
- Personalización de perfil y skins.
- Sistema de roles (VIP, miembro).
- Responsive y optimizado para SEO.

## 🧪 Pruebas

Actualmente, la validación se realiza manualmente. Se recomienda agregar pruebas unitarias para los módulos JS y pruebas E2E para la UI.

## 📦 Estructura del Proyecto

- `public/`: Archivos estáticos y HTML principal.
- `src/js/`: Lógica de frontend y conexión con Firebase.
- `src/css/`: Estilos personalizados.
- `src/config/`: Configuración de Firebase.
- `.env.example`: Plantilla para variables de entorno.

## 📄 Licencia

MIT

---

¡Gracias por usar Mine Of Servers! Para soporte, abre un issue o contacta a [contacto@mineofservers.com](mailto:contacto@mineofservers.com).